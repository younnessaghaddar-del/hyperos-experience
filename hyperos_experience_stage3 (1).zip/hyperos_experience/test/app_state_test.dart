import 'package:flutter_test/flutter_test.dart';
import 'package:hyperos_experience/app_state.dart';
import 'package:hyperos_experience/models/hyper_note.dart';
import 'package:hyperos_experience/data/notes_repository.dart';

class MemoryNotesRepository implements NotesRepository {
  List<HyperNote> stored = [];

  @override
  Future<List<HyperNote>> loadNotes() async => List.of(stored);

  @override
  Future<void> saveNotes(List<HyperNote> notes) async {
    stored = List.of(notes);
  }
}

void main() {
  group('AppState notes', () {
    late MemoryNotesRepository repository;
    late AppState state;

    setUp(() async {
      repository = MemoryNotesRepository();
      state = AppState(notesRepository: repository);
      await state.initialize();
    });

    test('creates and edits a note and persists it', () async {
      await state.saveNote(title: 'First', body: 'Draft');
      final created = state.notes.firstWhere((note) => note.title == 'First');

      await state.saveNote(id: created.id, title: 'Updated', body: 'Final text');

      final edited = state.notes.firstWhere((note) => note.id == created.id);
      expect(edited.title, 'Updated');
      expect(edited.body, 'Final text');
      expect(repository.stored.single.title, 'Updated');
    });

    test('loads saved notes after creating a fresh state', () async {
      await state.saveNote(title: 'Persistent', body: 'Saved locally');
      final reopened = AppState(notesRepository: repository);
      await reopened.initialize();

      expect(reopened.notes.single.title, 'Persistent');
      expect(reopened.notes.single.body, 'Saved locally');
    });


    test('serializes a note to and from JSON', () {
      final note = HyperNote(
        id: 'round-trip',
        title: 'JSON note',
        body: 'Keep this text',
        updatedAt: DateTime.utc(2026, 1, 2, 3, 4),
        isPinned: true,
      );

      final restored = HyperNote.fromJson(note.toJson());

      expect(restored.id, note.id);
      expect(restored.title, note.title);
      expect(restored.body, note.body);
      expect(restored.updatedAt, note.updatedAt);
      expect(restored.isPinned, isTrue);
    });

    test('pins and deletes a note and persists both changes', () async {
      await state.saveNote(title: 'Temporary', body: '');
      final note = state.notes.firstWhere((item) => item.title == 'Temporary');

      await state.toggleNotePin(note.id);
      expect(state.notes.firstWhere((item) => item.id == note.id).isPinned, isTrue);

      await state.deleteNote(note.id);
      expect(state.notes.any((item) => item.id == note.id), isFalse);
      expect(repository.stored, isEmpty);
    });
  });
}
