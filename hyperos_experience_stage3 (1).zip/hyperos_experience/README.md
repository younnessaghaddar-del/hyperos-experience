# HyperOS Experience — Flutter prototype (Stage 3)

An independent Android-first Flutter UI prototype inspired by modern HyperOS visual patterns. It is not Xiaomi software and does not replace Android system UI.

## Stage 3 improvements
- **Persistent Notes:** JSON-serialized notes stored locally with `shared_preferences`; notes survive normal app restarts. Loading and save errors are surfaced in the UI.
- **Gallery:** Android system photo-picker integration through `image_picker`; selected photos are displayed locally in the current screen session. Demo albums remain explicitly labeled as placeholders.
- **Weather architecture:** `WeatherSnapshot` model and `WeatherService` abstraction are separate from the screen. `SampleWeatherService` provides offline illustrative data, with loading and error/retry states.
- **Tests:** notes create/edit, pin/delete, and repository reload behavior use an in-memory test repository.
- Existing home, HyperIsland, Control Center, Connect, settings and app navigation architecture is retained.

## Run and verify
Install the Flutter SDK and Android Studio (including Android SDK/build tools). This source archive does not currently contain generated Android platform scaffolding, so create it once from the project root, then fetch packages and verify:

```bash
flutter create --platforms=android .
flutter pub get
flutter analyze
flutter test
flutter run
```

Build a release APK:

```bash
flutter build apk --release
```

APK output:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## Android photo picker
The Gallery uses `image_picker`'s `pickMultiImage`. On supported Android versions this uses the Android system Photo Picker where available; plugin fallback behavior depends on the Android version and plugin release. No broad storage permission is requested by this screen. Selected files are temporary/session-level references; this prototype does not import or index them into a permanent app-managed album.

## Remaining limitations
- Notes use `shared_preferences` for lightweight local persistence. It is not encrypted storage and is not intended for large datasets. For production, consider SQLite/Drift or Isar and add migration/backup handling.
- Gallery selections are session-only; no thumbnail cache, albums database, editor pipeline, or AI editing model is included. The gradient demo albums are placeholders.
- Weather uses sample values only. No API key/provider or location service is configured. Implement a concrete `WeatherService` for live forecasts and add caching/rate-limit handling.
- HyperIsland, lock screen, task manager, Control Center, device connectivity, and radio switches remain in-app simulations. Ordinary third-party apps cannot replace Android's system UI or control restricted system functions.
- No APK is included unless the release build command is run successfully in an Android build environment.

## Suggested next engineering steps
1. Add a production database and optional encrypted export for Notes.
2. Persist Gallery album metadata and cache selected thumbnails.
3. Add a real weather provider with API-key configuration and cached forecasts.
4. Add widget, accessibility, integration, and performance tests.
