import 'package:flutter/material.dart';

import '../models/weather_snapshot.dart';

abstract interface class WeatherService {
  Future<WeatherSnapshot> fetchWeather(String city);
}

/// Safe offline provider. Values are illustrative and never presented as live data.
class SampleWeatherService implements WeatherService {
  @override
  Future<WeatherSnapshot> fetchWeather(String city) async {
    await Future<void>.delayed(const Duration(milliseconds: 350));
    return WeatherSnapshot(
      city: city,
      condition: 'Partly cloudy',
      temperatureC: 22,
      feelsLikeC: 23,
      humidityPercent: 58,
      windKph: 14,
      uvIndex: 'Moderate',
      visibilityKm: 10,
      pressureHpa: 1014,
      hourly: const [
        HourlyForecast(time: 'Now', temperatureC: 22, icon: Icons.cloud_rounded),
        HourlyForecast(time: '17:00', temperatureC: 21, icon: Icons.wb_sunny_rounded),
        HourlyForecast(time: '18:00', temperatureC: 20, icon: Icons.cloud_rounded),
        HourlyForecast(time: '19:00', temperatureC: 19, icon: Icons.nights_stay_rounded),
      ],
      isSample: true,
      updatedAt: DateTime.now(),
    );
  }
}
