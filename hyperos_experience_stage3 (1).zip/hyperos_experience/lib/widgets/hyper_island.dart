import 'package:flutter/material.dart';
import 'glass_card.dart';

class HyperIsland extends StatelessWidget {
  const HyperIsland({super.key});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      radius: 30,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      color: const Color(0xFF050507),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.graphic_eq_rounded, size: 16, color: Color(0xFF9CB8FF)),
          SizedBox(width: 8),
          Text('Now playing', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
          SizedBox(width: 12),
          Icon(Icons.more_horiz, size: 17),
        ],
      ),
    );
  }
}
