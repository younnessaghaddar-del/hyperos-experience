import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/hyper_note.dart';

abstract interface class NotesRepository {
  Future<List<HyperNote>> loadNotes();
  Future<void> saveNotes(List<HyperNote> notes);
}

class SharedPreferencesNotesRepository implements NotesRepository {
  static const _storageKey = 'hyperos_experience.notes.v1';

  @override
  Future<List<HyperNote>> loadNotes() async {
    final preferences = await SharedPreferences.getInstance();
    final raw = preferences.getString(_storageKey);
    if (raw == null || raw.isEmpty) return <HyperNote>[];

    final decoded = jsonDecode(raw);
    if (decoded is! List) {
      throw const FormatException('Stored notes data is not a list.');
    }

    return decoded
        .whereType<Map>()
        .map((item) => HyperNote.fromJson(Map<String, dynamic>.from(item)))
        .toList();
  }

  @override
  Future<void> saveNotes(List<HyperNote> notes) async {
    final preferences = await SharedPreferences.getInstance();
    final encoded = jsonEncode(notes.map((note) => note.toJson()).toList());
    final saved = await preferences.setString(_storageKey, encoded);
    if (!saved) throw StateError('Could not save notes to local storage.');
  }
}
