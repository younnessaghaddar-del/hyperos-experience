import 'package:flutter/material.dart';

@immutable
class HourlyForecast {
  const HourlyForecast({
    required this.time,
    required this.temperatureC,
    required this.icon,
  });

  final String time;
  final int temperatureC;
  final IconData icon;
}

@immutable
class WeatherSnapshot {
  const WeatherSnapshot({
    required this.city,
    required this.condition,
    required this.temperatureC,
    required this.feelsLikeC,
    required this.humidityPercent,
    required this.windKph,
    required this.uvIndex,
    required this.visibilityKm,
    required this.pressureHpa,
    required this.hourly,
    required this.isSample,
    required this.updatedAt,
  });

  final String city;
  final String condition;
  final int temperatureC;
  final int feelsLikeC;
  final int humidityPercent;
  final int windKph;
  final String uvIndex;
  final int visibilityKm;
  final int pressureHpa;
  final List<HourlyForecast> hourly;
  final bool isSample;
  final DateTime updatedAt;
}
