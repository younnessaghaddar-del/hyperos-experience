import 'package:flutter/foundation.dart';

@immutable
class HyperNote {
  const HyperNote({
    required this.id,
    required this.title,
    required this.body,
    required this.updatedAt,
    this.isPinned = false,
  });

  final String id;
  final String title;
  final String body;
  final DateTime updatedAt;
  final bool isPinned;

  factory HyperNote.fromJson(Map<String, dynamic> json) {
    return HyperNote(
      id: json['id'] as String,
      title: json['title'] as String? ?? 'Untitled note',
      body: json['body'] as String? ?? '',
      updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
      isPinned: json['isPinned'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'updatedAt': updatedAt.toIso8601String(),
        'isPinned': isPinned,
      };

  HyperNote copyWith({
    String? title,
    String? body,
    DateTime? updatedAt,
    bool? isPinned,
  }) {
    return HyperNote(
      id: id,
      title: title ?? this.title,
      body: body ?? this.body,
      updatedAt: updatedAt ?? this.updatedAt,
      isPinned: isPinned ?? this.isPinned,
    );
  }
}
