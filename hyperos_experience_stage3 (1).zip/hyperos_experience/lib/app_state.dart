import 'package:flutter/foundation.dart';

import 'data/notes_repository.dart';
import 'models/hyper_note.dart';

class AppState extends ChangeNotifier {
  AppState({NotesRepository? notesRepository})
      : _notesRepository =
            notesRepository ?? SharedPreferencesNotesRepository();

  final NotesRepository _notesRepository;
  int _tab = 0;
  bool wifi = true;
  bool bluetooth = true;
  bool flashlight = false;
  bool dnd = false;
  double brightness = 0.72;
  double volume = 0.48;
  bool sharedClipboard = true;
  bool crossDeviceCamera = false;
  bool darkMode = true;

  final List<HyperNote> _notes = [];
  bool notesLoading = false;
  String? notesError;
  bool _initialized = false;

  int get tab => _tab;
  List<HyperNote> get notes => List.unmodifiable(_notes);

  Future<void> initialize() async {
    if (_initialized || notesLoading) return;
    notesLoading = true;
    notesError = null;
    notifyListeners();
    try {
      _notes
        ..clear()
        ..addAll(await _notesRepository.loadNotes());
      _sortNotes();
      _initialized = true;
    } catch (error) {
      notesError = 'Notes could not be loaded: $error';
    } finally {
      notesLoading = false;
      notifyListeners();
    }
  }

  void setTab(int value) {
    _tab = value;
    notifyListeners();
  }

  void toggle(String key) {
    switch (key) {
      case 'wifi':
        wifi = !wifi;
        break;
      case 'bluetooth':
        bluetooth = !bluetooth;
        break;
      case 'flashlight':
        flashlight = !flashlight;
        break;
      case 'dnd':
        dnd = !dnd;
        break;
      case 'clipboard':
        sharedClipboard = !sharedClipboard;
        break;
      case 'camera':
        crossDeviceCamera = !crossDeviceCamera;
        break;
    }
    notifyListeners();
  }

  void setBrightness(double value) {
    brightness = value;
    notifyListeners();
  }

  void setVolume(double value) {
    volume = value;
    notifyListeners();
  }

  Future<void> saveNote({
    String? id,
    required String title,
    required String body,
  }) async {
    final cleanTitle = title.trim().isEmpty ? 'Untitled note' : title.trim();
    final existingIndex =
        id == null ? -1 : _notes.indexWhere((note) => note.id == id);

    if (existingIndex >= 0) {
      final old = _notes[existingIndex];
      _notes[existingIndex] = old.copyWith(
        title: cleanTitle,
        body: body.trim(),
        updatedAt: DateTime.now(),
      );
    } else {
      _notes.insert(
        0,
        HyperNote(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          title: cleanTitle,
          body: body.trim(),
          updatedAt: DateTime.now(),
        ),
      );
    }
    _sortNotes();
    await _persistNotes();
    notifyListeners();
  }

  Future<void> toggleNotePin(String id) async {
    final index = _notes.indexWhere((note) => note.id == id);
    if (index < 0) return;
    _notes[index] = _notes[index].copyWith(isPinned: !_notes[index].isPinned);
    _sortNotes();
    await _persistNotes();
    notifyListeners();
  }

  Future<void> deleteNote(String id) async {
    _notes.removeWhere((note) => note.id == id);
    await _persistNotes();
    notifyListeners();
  }

  Future<void> _persistNotes() async {
    try {
      await _notesRepository.saveNotes(_notes);
      notesError = null;
    } catch (error) {
      notesError = 'Changes could not be saved: $error';
    }
  }

  void _sortNotes() {
    _notes.sort((a, b) {
      if (a.isPinned != b.isPinned) return a.isPinned ? -1 : 1;
      return b.updatedAt.compareTo(a.updatedAt);
    });
  }
}
