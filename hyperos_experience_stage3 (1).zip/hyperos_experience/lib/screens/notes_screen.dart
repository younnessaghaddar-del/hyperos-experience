import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../models/hyper_note.dart';
import '../widgets/glass_card.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final allNotes = appState.notes;
    final filtered = allNotes.where((note) {
      final query = _query.toLowerCase();
      return note.title.toLowerCase().contains(query) ||
          note.body.toLowerCase().contains(query);
    }).toList();

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Notes'),
        actions: [
          IconButton(
            tooltip: 'New note',
            onPressed: () => _openEditor(context),
            icon: const Icon(Icons.add_rounded),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(context),
        icon: const Icon(Icons.edit_note_rounded),
        label: const Text('New note'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
        children: [
          if (appState.notesLoading) const LinearProgressIndicator(minHeight: 2),
          if (appState.notesError != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(appState.notesError!,
                      style: const TextStyle(color: Colors.orangeAccent)),
                  TextButton(
                    onPressed: appState.initialize,
                    child: const Text('Retry loading notes'),
                  ),
                ],
              ),
            ),
          const Text(
            'DeepThink Notes',
            style: TextStyle(fontSize: 25, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 5),
          const Text(
            'Capture ideas and keep them organized.',
            style: TextStyle(color: Colors.white60),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: _searchController,
            onChanged: (value) => setState(() => _query = value),
            decoration: InputDecoration(
              hintText: 'Search notes',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: _query.isEmpty
                  ? null
                  : IconButton(
                      onPressed: () {
                        _searchController.clear();
                        setState(() => _query = '');
                      },
                      icon: const Icon(Icons.close_rounded),
                    ),
              filled: true,
              fillColor: Colors.white.withOpacity(.08),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(20),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 18),
          if (filtered.isEmpty)
            GlassCard(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 28),
                child: Center(
                  child: Text(
                    _query.isEmpty
                        ? 'No notes yet. Create your first note.'
                        : 'No matching notes found.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white70),
                  ),
                ),
              ),
            )
          else
            ...filtered.map((note) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: GlassCard(
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: () => _openEditor(context, note: note),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  note.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              if (note.isPinned)
                                const Icon(Icons.push_pin_rounded, size: 17,
                                    color: Color(0xFFFFD58A)),
                              PopupMenuButton<String>(
                                onSelected: (action) {
                                  final state = context.read<AppState>();
                                  if (action == 'pin') {
                                    state.toggleNotePin(note.id);
                                  } else if (action == 'delete') {
                                    state.deleteNote(note.id);
                                  }
                                },
                                itemBuilder: (_) => [
                                  PopupMenuItem(
                                    value: 'pin',
                                    child: Text(note.isPinned ? 'Unpin' : 'Pin'),
                                  ),
                                  const PopupMenuItem(
                                    value: 'delete',
                                    child: Text('Delete'),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          if (note.body.isNotEmpty) ...[
                            const SizedBox(height: 5),
                            Text(
                              note.body,
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  color: Colors.white70, height: 1.35),
                            ),
                          ],
                          const SizedBox(height: 10),
                          Text(
                            _formatDate(note.updatedAt),
                            style: const TextStyle(
                                color: Colors.white38, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                  ),
                )),
        ],
      ),
    );
  }

  Future<void> _openEditor(BuildContext context, {HyperNote? note}) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => NoteEditorScreen(note: note),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final local = date.toLocal();
    final twoDigit = (int value) => value.toString().padLeft(2, '0');
    return '${twoDigit(local.day)}/${twoDigit(local.month)}/${local.year} '
        '${twoDigit(local.hour)}:${twoDigit(local.minute)}';
  }
}

class NoteEditorScreen extends StatefulWidget {
  const NoteEditorScreen({super.key, this.note});

  final HyperNote? note;

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  late final TextEditingController _titleController;
  late final TextEditingController _bodyController;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.note?.title ?? '');
    _bodyController = TextEditingController(text: widget.note?.body ?? '');
  }

  @override
  void dispose() {
    _titleController.dispose();
    _bodyController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await context.read<AppState>().saveNote(
          id: widget.note?.id,
          title: _titleController.text,
          body: _bodyController.text,
        );
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF12151D),
      appBar: AppBar(
        title: Text(widget.note == null ? 'New note' : 'Edit note'),
        actions: [
          TextButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.check_rounded),
            label: const Text('Save'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: _titleController,
            textCapitalization: TextCapitalization.sentences,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w600),
            decoration: const InputDecoration(
              hintText: 'Title',
              border: InputBorder.none,
            ),
          ),
          const Divider(color: Colors.white12),
          TextField(
            controller: _bodyController,
            minLines: 12,
            maxLines: null,
            keyboardType: TextInputType.multiline,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(
              hintText: 'Start writing...',
              border: InputBorder.none,
            ),
          ),
          const SizedBox(height: 18),
          const GlassCard(
            child: Row(
              children: [
                Icon(Icons.auto_awesome_rounded,
                    color: Color(0xFFB9C9FF)),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'AI summary card — connect an AI service to generate summaries.',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
