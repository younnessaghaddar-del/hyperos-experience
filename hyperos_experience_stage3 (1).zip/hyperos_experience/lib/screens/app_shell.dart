import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../widgets/glass_card.dart';
import 'home_screen.dart';
import 'ecosystem_screen.dart';
import 'utilities_screen.dart';
import 'settings_screen.dart';
import 'lock_screen.dart';
import 'task_manager_screen.dart';
import 'control_center.dart';

class AppShell extends StatelessWidget {
  const AppShell({super.key});

  static const _pages = [
    HomeScreen(),
    EcosystemScreen(),
    UtilitiesScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF252C3C), Color(0xFF111319), Color(0xFF171522)],
                ),
              ),
            ),
          ),
          SafeArea(child: _pages[state.tab]),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: state.tab,
        onDestinationSelected: state.setTab,
        backgroundColor: const Color(0xEE17191F),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.devices_rounded), label: 'Connect'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'Apps'),
          NavigationDestination(icon: Icon(Icons.tune_rounded), label: 'Settings'),
        ],
      ),
      floatingActionButton: FloatingActionButton.small(
        tooltip: 'Control Center',
        onPressed: () => showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (_) => const ControlCenter(),
        ),
        child: const Icon(Icons.tune_rounded),
      ),
      drawer: Drawer(
        backgroundColor: const Color(0xFF191C24),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text('HyperOS Experience', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              ListTile(leading: const Icon(Icons.lock_outline), title: const Text('Lock screen demo'), onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const LockScreen()));
              }),
              ListTile(leading: const Icon(Icons.layers_outlined), title: const Text('Recent apps'), onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const TaskManagerScreen()));
              }),
              ListTile(leading: const Icon(Icons.tune), title: const Text('Control Center'), onTap: () {
                Navigator.pop(context);
                showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => const ControlCenter());
              }),
            ],
          ),
        ),
      ),
    );
  }
}
