import 'package:flutter/material.dart';
import '../widgets/glass_card.dart';
import '../widgets/hyper_island.dart';
import 'lock_screen.dart';
import 'task_manager_screen.dart';
import 'control_center.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final apps = [
      _AppItem('Weather', Icons.cloud_rounded, const Color(0xFF70B9F5)),
      _AppItem('Gallery', Icons.photo_library_rounded, const Color(0xFFE99A9A)),
      _AppItem('Notes', Icons.sticky_note_2_rounded, const Color(0xFFF0C66D)),
      _AppItem('Files', Icons.folder_rounded, const Color(0xFF9CB8FF)),
      _AppItem('Recorder', Icons.mic_rounded, const Color(0xFFB69BEF)),
      _AppItem('AI Tools', Icons.auto_awesome_rounded, const Color(0xFF79D5C1)),
    ];
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Tuesday, November 14', style: TextStyle(fontSize: 14, color: Colors.white70)),
        actions: [
          IconButton(icon: const Icon(Icons.lock_outline), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LockScreen()))),
          IconButton(icon: const Icon(Icons.layers_outlined), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TaskManagerScreen()))),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
        children: [
          const Center(child: HyperIsland()),
          const SizedBox(height: 26),
          const Text('16:07', style: TextStyle(fontSize: 58, fontWeight: FontWeight.w300, letterSpacing: -2)),
          const Text('Your day, at a glance', style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 22),
          GlassCard(
            child: Row(
              children: [
                const Icon(Icons.wb_cloudy_rounded, size: 42, color: Color(0xFFB9D8FF)),
                const SizedBox(width: 14),
                const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Tangier', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
                  Text('Weather preview · Demo data', style: TextStyle(color: Colors.white60, fontSize: 12)),
                ])),
                const Text('22°', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w300)),
              ],
            ),
          ),
          const SizedBox(height: 14),
          GlassCard(
            child: Row(
              children: [
                const Icon(Icons.battery_5_bar_rounded, size: 32, color: Color(0xFF9DDBB4)),
                const SizedBox(width: 12),
                const Expanded(child: Text('Battery status')),
                Text('86%', style: TextStyle(color: Colors.white.withOpacity(.8), fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Text('Your apps', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
          const SizedBox(height: 14),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: apps.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 18, crossAxisSpacing: 12, childAspectRatio: .95),
            itemBuilder: (context, index) => InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${apps[index].name} demo selected'))),
              child: Column(
                children: [
                  Container(
                    width: 58, height: 58,
                    decoration: BoxDecoration(color: apps[index].color.withOpacity(.18), borderRadius: BorderRadius.circular(21)),
                    child: Icon(apps[index].icon, color: apps[index].color, size: 29),
                  ),
                  const SizedBox(height: 8),
                  Text(apps[index].name, style: const TextStyle(fontSize: 12)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          OutlinedButton.icon(
            onPressed: () => showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => const ControlCenter()),
            icon: const Icon(Icons.dashboard_customize_outlined),
            label: const Text('Open Control Center'),
          ),
        ],
      ),
    );
  }
}

class _AppItem {
  const _AppItem(this.name, this.icon, this.color);
  final String name;
  final IconData icon;
  final Color color;
}
