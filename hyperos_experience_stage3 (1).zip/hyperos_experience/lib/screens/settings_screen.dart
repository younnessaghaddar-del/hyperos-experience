import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../widgets/glass_card.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(backgroundColor: Colors.transparent, title: const Text('Experience settings')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('HyperOS Experience', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          SizedBox(height: 6), Text('Interactive concept · Version 1.0.0', style: TextStyle(color: Colors.white60)),
        ])),
        const SizedBox(height: 14),
        SwitchListTile(title: const Text('Dark appearance'), value: state.darkMode, onChanged: (_) { state.darkMode = !state.darkMode; state.notifyListeners(); }),
        const ListTile(leading: Icon(Icons.animation), title: Text('Animation scale'), subtitle: Text('Designed for smooth 60 FPS UI transitions')),
        const ListTile(leading: Icon(Icons.security), title: Text('Privacy dashboard'), subtitle: Text('Demo permissions overview')),
        const ListTile(leading: Icon(Icons.info_outline), title: Text('About'), subtitle: Text('Independent concept; not affiliated with Xiaomi')),
      ]),
    );
  }
}
