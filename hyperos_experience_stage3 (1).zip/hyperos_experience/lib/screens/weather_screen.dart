import 'package:flutter/material.dart';

import '../models/weather_snapshot.dart';
import '../services/weather_service.dart';
import '../widgets/glass_card.dart';

class WeatherScreen extends StatefulWidget {
  const WeatherScreen({super.key, this.service});

  final WeatherService? service;

  @override
  State<WeatherScreen> createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  late final WeatherService _service;
  WeatherSnapshot? _weather;
  bool _loading = true;
  String? _error;
  bool _showDetails = false;
  String _city = 'Tangier, Morocco';

  @override
  void initState() {
    super.initState();
    _service = widget.service ?? SampleWeatherService();
    _loadWeather();
  }

  Future<void> _loadWeather() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final result = await _service.fetchWeather(_city);
      if (!mounted) return;
      setState(() {
        _weather = result;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = 'Weather data could not be loaded. $error';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final weather = _weather;
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Weather'),
        actions: [
          IconButton(
            tooltip: 'Refresh sample data',
            onPressed: _loading ? null : _loadWeather,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _loading && weather == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
              children: [
                const Text('Weather overview',
                    style:
                        TextStyle(fontSize: 25, fontWeight: FontWeight.w600)),
                const SizedBox(height: 5),
                const Text('Forecast interface preview',
                    style: TextStyle(color: Colors.white60)),
                const SizedBox(height: 18),
                if (_error != null)
                  GlassCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_error!,
                            style: const TextStyle(color: Colors.orangeAccent)),
                        TextButton(
                            onPressed: _loadWeather,
                            child: const Text('Try again')),
                      ],
                    ),
                  ),
                if (weather != null) ...[
                  _CurrentWeatherCard(weather: weather),
                  const SizedBox(height: 18),
                  const Text('Hourly forecast',
                      style:
                          TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 12),
                  GlassCard(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: weather.hourly
                          .map((item) => _ForecastItem(item: item))
                          .toList(),
                    ),
                  ),
                  const SizedBox(height: 18),
                  GlassCard(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const Expanded(
                              child: Text('Weather details',
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600)),
                            ),
                            IconButton(
                              onPressed: () => setState(
                                  () => _showDetails = !_showDetails),
                              icon: Icon(_showDetails
                                  ? Icons.expand_less
                                  : Icons.expand_more),
                            ),
                          ],
                        ),
                        if (_showDetails) ...[
                          const Divider(color: Colors.white12),
                          _DetailRow(
                              label: 'Feels like',
                              value: '${weather.feelsLikeC}°'),
                          _DetailRow(
                              label: 'UV index', value: weather.uvIndex),
                          _DetailRow(
                              label: 'Visibility',
                              value: '${weather.visibilityKm} km'),
                          _DetailRow(
                              label: 'Pressure',
                              value: '${weather.pressureHpa} hPa'),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _DataSourceNotice(isSample: weather.isSample),
                ],
                if (_loading && weather != null)
                  const Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: LinearProgressIndicator(minHeight: 2),
                  ),
              ],
            ),
    );
  }
}

class _CurrentWeatherCard extends StatelessWidget {
  const _CurrentWeatherCard({required this.weather});

  final WeatherSnapshot weather;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF477F9D), Color(0xFF263E60), Color(0xFF242A43)],
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF659CC7).withOpacity(.18),
            blurRadius: 28,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: 28,
            right: 25,
            child: Icon(Icons.wb_sunny_rounded,
                size: 110, color: Colors.white.withOpacity(.24)),
          ),
          Positioned(
            top: 60,
            left: 22,
            child: Icon(Icons.cloud_rounded,
                size: 85, color: Colors.white.withOpacity(.30)),
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(weather.city,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w600)),
                const SizedBox(height: 26),
                Text('${weather.temperatureC}°',
                    style: const TextStyle(
                        fontSize: 76, fontWeight: FontWeight.w200, height: 1)),
                Text(weather.condition, style: const TextStyle(fontSize: 17)),
                const Spacer(),
                Row(
                  children: [
                    _WeatherMetric(
                        icon: Icons.water_drop_outlined,
                        label: 'Humidity',
                        value: '${weather.humidityPercent}%'),
                    const SizedBox(width: 22),
                    _WeatherMetric(
                        icon: Icons.air_rounded,
                        label: 'Wind',
                        value: '${weather.windKph} km/h'),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  'Updated ${weather.updatedAt.toLocal()}',
                  style: const TextStyle(color: Colors.white70, fontSize: 10),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DataSourceNotice extends StatelessWidget {
  const _DataSourceNotice({required this.isSample});

  final bool isSample;

  @override
  Widget build(BuildContext context) {
    return Text(
      isSample
          ? 'Sample data only — these values are illustrative, not current conditions. Connect a weather provider to enable live forecasts.'
          : 'Weather supplied by the configured provider.',
      style: const TextStyle(color: Colors.white54, fontSize: 12, height: 1.4),
    );
  }
}

class _WeatherMetric extends StatelessWidget {
  const _WeatherMetric(
      {required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 19),
        const SizedBox(width: 7),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: const TextStyle(color: Colors.white70, fontSize: 10)),
            Text(value,
                style:
                    const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ],
        ),
      ],
    );
  }
}

class _ForecastItem extends StatelessWidget {
  const _ForecastItem({required this.item});

  final HourlyForecast item;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(item.time,
            style: const TextStyle(color: Colors.white60, fontSize: 11)),
        const SizedBox(height: 12),
        Icon(item.icon, color: const Color(0xFFD8E7FF), size: 23),
        const SizedBox(height: 12),
        Text('${item.temperatureC}°',
            style: const TextStyle(fontWeight: FontWeight.w600)),
      ],
    );
  }
}

class _DetailRow extends StatelessWidget {
  const _DetailRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        children: [
          Expanded(
              child: Text(label,
                  style: const TextStyle(color: Colors.white60))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
