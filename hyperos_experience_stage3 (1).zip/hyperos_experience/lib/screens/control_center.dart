import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../widgets/glass_card.dart';

class ControlCenter extends StatelessWidget {
  const ControlCenter({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Container(
      height: MediaQuery.of(context).size.height * .78,
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
      decoration: const BoxDecoration(
        color: Color(0xFF171A22),
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      child: ListView(
        children: [
          Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white30, borderRadius: BorderRadius.circular(9)))),
          const SizedBox(height: 24),
          const Text('Control Center', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w600)),
          const SizedBox(height: 18),
          GridView.count(
            crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.8,
            children: [
              _ToggleTile(label: 'Wi-Fi', icon: Icons.wifi, active: state.wifi, onTap: () => state.toggle('wifi')),
              _ToggleTile(label: 'Bluetooth', icon: Icons.bluetooth, active: state.bluetooth, onTap: () => state.toggle('bluetooth')),
              _ToggleTile(label: 'Flashlight', icon: Icons.flashlight_on, active: state.flashlight, onTap: () => state.toggle('flashlight')),
              _ToggleTile(label: 'Do not disturb', icon: Icons.do_not_disturb_on, active: state.dnd, onTap: () => state.toggle('dnd')),
            ],
          ),
          const SizedBox(height: 18),
          GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Brightness', style: TextStyle(fontWeight: FontWeight.w600)),
            Slider(value: state.brightness, onChanged: state.setBrightness),
            const Text('Volume', style: TextStyle(fontWeight: FontWeight.w600)),
            Slider(value: state.volume, onChanged: state.setVolume),
          ])),
          const SizedBox(height: 14),
          const GlassCard(child: Row(children: [Icon(Icons.screen_record), SizedBox(width: 12), Text('Screen recording · UI demo')])),
        ],
      ),
    );
  }
}

class _ToggleTile extends StatelessWidget {
  const _ToggleTile({required this.label, required this.icon, required this.active, required this.onTap});
  final String label;
  final IconData icon;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap, borderRadius: BorderRadius.circular(22),
      child: GlassCard(
        color: active ? const Color(0xFF526D9F) : const Color(0xFF292D37),
        child: Row(children: [Icon(icon), const SizedBox(width: 10), Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600)))]),
      ),
    );
  }
}
