import 'package:flutter/material.dart';
import '../widgets/glass_card.dart';

class TaskManagerScreen extends StatelessWidget {
  const TaskManagerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tasks = ['Gallery', 'Weather', 'Notes', 'File Manager'];
    return Scaffold(
      appBar: AppBar(title: const Text('Recent apps')),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const GlassCard(child: Row(children: [
            Icon(Icons.memory, size: 30), SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Memory overview'), Text('4.2 GB / 8 GB · illustrative value', style: TextStyle(color: Colors.white60, fontSize: 12)),
            ])),
          ])),
          const SizedBox(height: 20),
          Expanded(child: GridView.builder(
            itemCount: tasks.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12),
            itemBuilder: (_, i) => GlassCard(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.window_rounded, size: 34), const SizedBox(height: 12), Text(tasks[i]),
            ])),
          )),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.done_all), label: const Text('Clear demo tasks'))),
        ]),
      ),
    );
  }
}
