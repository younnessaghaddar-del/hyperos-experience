import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../widgets/glass_card.dart';

class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});

  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  final ImagePicker _picker = ImagePicker();
  final List<XFile> _selectedImages = [];
  String _category = 'All';
  bool _isPicking = false;
  String? _pickerError;

  static const _categories = ['All', 'Device photos', 'Scenery', 'Documents'];

  Future<void> _pickImages() async {
    setState(() {
      _isPicking = true;
      _pickerError = null;
    });
    try {
      final images = await _picker.pickMultiImage(imageQuality: 90);
      if (!mounted) return;
      if (images.isNotEmpty) {
        setState(() => _selectedImages.insertAll(0, images));
      }
    } catch (error) {
      if (mounted) {
        setState(() => _pickerError =
            'Photo picker is unavailable on this device: $error');
      }
    } finally {
      if (mounted) setState(() => _isPicking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final showingDevicePhotos =
        _category == 'All' || _category == 'Device photos';

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Gallery'),
        actions: [
          IconButton(
            tooltip: 'Choose photos',
            onPressed: _isPicking ? null : _pickImages,
            icon: const Icon(Icons.add_photo_alternate_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
        children: [
          const Text('Your moments',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.w600)),
          const SizedBox(height: 5),
          const Text('Select images using the Android system photo picker.',
              style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 18),
          if (_pickerError != null)
            _MessageCard(
              icon: Icons.warning_amber_rounded,
              message: _pickerError!,
            ),
          if (_isPicking) const LinearProgressIndicator(minHeight: 2),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _categories
                .map((category) => ChoiceChip(
                      label: Text(category),
                      selected: _category == category,
                      onSelected: (_) => setState(() => _category = category),
                    ))
                .toList(),
          ),
          const SizedBox(height: 18),
          if (showingDevicePhotos && _selectedImages.isNotEmpty) ...[
            Text('Device photos (${_selectedImages.length})',
                style: const TextStyle(
                    fontSize: 17, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _selectedImages.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemBuilder: (context, index) {
                final file = _selectedImages[index];
                return ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.file(
                    File(file.path),
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const ColoredBox(
                      color: Color(0xFF292E3A),
                      child: Center(child: Icon(Icons.broken_image_outlined)),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
          ],
          const Text('Demo albums',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          if (_category == 'All' ||
              _category == 'Scenery' ||
              _category == 'Documents')
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: .92,
              children: [
                if (_category == 'All' || _category == 'Scenery')
                  const _DemoAlbum(
                    title: 'Scenery',
                    subtitle: 'Demo album',
                    icon: Icons.landscape_rounded,
                    colors: [Color(0xFF356B78), Color(0xFF1C3449)],
                  ),
                if (_category == 'All' || _category == 'Documents')
                  const _DemoAlbum(
                    title: 'Documents',
                    subtitle: 'Demo album',
                    icon: Icons.description_outlined,
                    colors: [Color(0xFF655D8A), Color(0xFF302D4D)],
                  ),
              ],
            ),
          const SizedBox(height: 16),
          const _MessageCard(
            icon: Icons.info_outline_rounded,
            message:
                'Demo albums are illustrative placeholders. Photos you choose are shown locally in this session; this prototype does not copy them into a permanent gallery.',
          ),
          const SizedBox(height: 12),
          GlassCard(
            child: ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.auto_awesome, color: Color(0xFFB8CCFF)),
              title: const Text('AI editor preview'),
              subtitle: const Text(
                  'Eraser, expand and adjust tools are visual previews only.'),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => showModalBottomSheet<void>(
                context: context,
                backgroundColor: const Color(0xFF20242E),
                builder: (_) => const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text(
                    'AI editing is not connected. Add an image-processing model or service to enable these tools.',
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _isPicking ? null : _pickImages,
        icon: const Icon(Icons.add_photo_alternate_rounded),
        label: const Text('Add photos'),
      ),
    );
  }
}

class _DemoAlbum extends StatelessWidget {
  const _DemoAlbum({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.colors,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 46, color: Colors.white70),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          Text(subtitle,
              style: const TextStyle(color: Colors.white60, fontSize: 11)),
        ],
      ),
    );
  }
}

class _MessageCard extends StatelessWidget {
  const _MessageCard({required this.icon, required this.message});

  final IconData icon;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GlassCard(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: const Color(0xFFB8CCFF)),
            const SizedBox(width: 12),
            Expanded(
              child: Text(message,
                  style: const TextStyle(color: Colors.white70, height: 1.4)),
            ),
          ],
        ),
      ),
    );
  }
}
