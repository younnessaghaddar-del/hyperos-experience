import 'package:flutter/material.dart';

import 'gallery_screen.dart';
import 'notes_screen.dart';
import 'weather_screen.dart';
import '../widgets/glass_card.dart';

class UtilitiesScreen extends StatelessWidget {
  const UtilitiesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tools = [
      _Tool('Weather', Icons.cloud_outlined,
          'Atmospheric forecast interface', const WeatherScreen()),
      _Tool('Gallery', Icons.photo_library_outlined,
          'Albums and editor preview', const GalleryScreen()),
      _Tool('File Manager', Icons.folder_open_outlined,
          'Docs · Images · Videos · APKs', null),
      _Tool('Notes', Icons.note_alt_outlined,
          'Create, edit, search and pin notes', const NotesScreen()),
      _Tool('Recorder', Icons.graphic_eq,
          'Waveform and transcript UI placeholder', null),
      _Tool('AI Assistant', Icons.auto_awesome_outlined,
          'Writing and summarization demo', null),
      _Tool('Privacy', Icons.privacy_tip_outlined,
          'Permissions dashboard preview', null),
    ];

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('System apps'),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(18),
        itemCount: tools.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final tool = tools[index];
          return GlassCard(
            child: ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(tool.icon,
                  size: 30, color: const Color(0xFFB8CCFF)),
              title: Text(tool.name),
              subtitle: Text(
                tool.description,
                style: const TextStyle(color: Colors.white60, fontSize: 12),
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                if (tool.screen != null) {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => tool.screen!),
                  );
                } else {
                  showModalBottomSheet<void>(
                    context: context,
                    backgroundColor: const Color(0xFF20242E),
                    builder: (_) => Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(tool.name,
                              style: const TextStyle(
                                  fontSize: 22, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 10),
                          Text(
                            '${tool.description}. This is a UI prototype; '
                            'connect a platform service or backend to enable it.',
                          ),
                          const SizedBox(height: 20),
                        ],
                      ),
                    ),
                  );
                }
              },
            ),
          );
        },
      ),
    );
  }
}

class _Tool {
  const _Tool(this.name, this.icon, this.description, this.screen);

  final String name;
  final IconData icon;
  final String description;
  final Widget? screen;
}
