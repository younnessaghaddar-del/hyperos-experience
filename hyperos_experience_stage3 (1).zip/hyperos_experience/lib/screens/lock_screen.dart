import 'package:flutter/material.dart';
import '../widgets/glass_card.dart';

class LockScreen extends StatelessWidget {
  const LockScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(fit: StackFit.expand, children: [
        const DecoratedBox(decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [Color(0xFF7186A9), Color(0xFF27334C), Color(0xFF10131D)]),
        )),
        Positioned(top: 100, left: 0, right: 0, child: Column(children: const [
          Text('16:07', style: TextStyle(fontSize: 76, fontWeight: FontWeight.w200, letterSpacing: -3)),
          Text('Saturday, November 14', style: TextStyle(color: Colors.white70)),
        ])),
        Positioned(bottom: 50, left: 24, right: 24, child: Column(children: [
          const GlassCard(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.fingerprint, size: 36), SizedBox(width: 12), Text('Fingerprint animation preview'),
          ])),
          const SizedBox(height: 18),
          const Text('Swipe up to unlock (demo)', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 12),
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Exit lock screen preview')),
        ])),
      ]),
    );
  }
}
