import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../widgets/glass_card.dart';

class EcosystemScreen extends StatelessWidget {
  const EcosystemScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final devices = [
      ('Tablet', Icons.tablet_mac), ('Smart Watch', Icons.watch), ('Smart TV', Icons.tv), ('PC', Icons.computer),
    ];
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(backgroundColor: Colors.transparent, title: const Text('HyperConnect')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const Text('Nearby devices', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
        const Text('Simulated device discovery', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 18),
        ...devices.map((d) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: GlassCard(child: Row(children: [Icon(d.$2, size: 30), const SizedBox(width: 14), Expanded(child: Text(d.$1)), const Text('Ready', style: TextStyle(color: Color(0xFF9DDBB4)))])),
        )),
        const SizedBox(height: 18),
        const Text('Shared features', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
        SwitchListTile(title: const Text('Shared clipboard'), value: state.sharedClipboard, onChanged: (_) => state.toggle('clipboard')),
        SwitchListTile(title: const Text('Cross-device camera'), value: state.crossDeviceCamera, onChanged: (_) => state.toggle('camera')),
        const GlassCard(child: Text('File transfer and live camera streaming require a real peer-to-peer connection and are not enabled in this UI prototype.')),
      ]),
    );
  }
}
